export async function onRequestPost(context) {
  const form = await context.request.formData();
  const name = String(form.get('name') || '').trim();
  const email = String(form.get('email') || '').trim();
  const phone = String(form.get('phone') || '').trim();
  const service = String(form.get('service') || '').trim();
  const message = String(form.get('message') || '').trim();
  if (!name || !email || !phone || !message) return new Response('Please complete all required fields.', {status:400});
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return new Response('Please enter a valid email address.', {status:400});
  const escape = s => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const html = `<h2>NGP Website Enquiry</h2><p><b>Name:</b> ${escape(name)}</p><p><b>Email:</b> ${escape(email)}</p><p><b>Phone:</b> ${escape(phone)}</p><p><b>Service:</b> ${escape(service)}</p><p><b>Message:</b><br>${escape(message).replace(/\n/g,'<br>')}</p>`;
  const text = `NGP Website Enquiry\n\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\nService: ${service}\n\n${message}`;
  try {
    await context.env.EMAIL.send({to:'ngpintegratedserviceslimited@gmail.com',from:'website@ngpintegratedservices.com',replyTo:email,subject:`NGP Website Enquiry - ${service || 'General'}`,html,text});
    return Response.redirect(new URL('/thank-you.html', context.request.url), 303);
  } catch (e) {
    return new Response('Unable to send your enquiry right now. Please call 09012532054 or 08162371966.', {status:500});
  }
}
