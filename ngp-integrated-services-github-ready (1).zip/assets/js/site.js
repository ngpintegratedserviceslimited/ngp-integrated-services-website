(function(){
  const consentKey='ngp_cookie_consent';
  function applyConsent(){
    if(localStorage.getItem(consentKey)==='accepted'){
      gtag('consent','update',{analytics_storage:'granted',ad_storage:'granted',ad_user_data:'granted',ad_personalization:'granted'});
      const c=document.getElementById('cookie'); if(c)c.style.display='none';
    }
  }
  window.acceptCookies=function(){
    localStorage.setItem(consentKey,'accepted');
    gtag('consent','update',{analytics_storage:'granted',ad_storage:'granted',ad_user_data:'granted',ad_personalization:'granted'});
    const c=document.getElementById('cookie'); if(c)c.style.display='none';
  };
  window.toggleMenu=function(){const n=document.getElementById('navLinks'); if(n)n.classList.toggle('open');};
  document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());applyConsent();});
})();
