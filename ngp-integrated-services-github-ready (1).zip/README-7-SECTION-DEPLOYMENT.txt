NGP INTEGRATED SERVICES LIMITED — 7-SECTION CLOUDFLARE PACKAGE

Main navigation:
HOME | ABOUT | SERVICES | SOLUTIONS & PROJECTS | TRAINING & ACADEMY | PARTNERSHIP | CONTACT

Core service divisions remain under Services:
1. Automated Gate Systems & Smart Security Solutions
2. ICT & Digital Solutions
3. Engineering & Infrastructure Services
4. Security Services
5. Digital Printing & Signage Solutions
6. Transportation & Logistics Support
7. Consultancy Services

Deployment target:
Cloudflare Workers/Pages with the existing /functions/api/submit.js enquiry endpoint.

Important:
Replace the contents of the GitHub deployment repository with the contents of this folder (not the parent folder itself). Do not upload .git, .wrangler or other repository metadata as public website assets.
Do not change production DNS until the Worker deployment has been retested.
