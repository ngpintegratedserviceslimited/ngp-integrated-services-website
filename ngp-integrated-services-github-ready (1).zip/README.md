# NGP Integrated Services Limited — Website

Consolidated website package for **NGP INTEGRATED SERVICES LIMITED**.

## Website sections

- Home
- About
- Services
- Solutions & Projects
- Training & Academy
- Partnership
- Contact
- Privacy Policy
- Cookie Policy
- Terms & Conditions
- Thank You / 404 pages

## Core service divisions

1. Automated Gate Systems & Smart Security Solutions
2. ICT & Digital Solutions
3. Engineering & Infrastructure Services
4. Security Services
5. Digital Printing & Signage Solutions
6. Transportation & Logistics Support
7. Consultancy Services

## Deployment

This repository contains static HTML/CSS/JavaScript plus the Cloudflare Pages Function:

`functions/api/submit.js`

The contact form posts to:

`/api/submit`

Therefore, **GitHub Pages can host the static website but cannot execute the Cloudflare Pages Function**. For the enquiry form to work, deploy this repository to Cloudflare Pages/Workers (or use a separate form backend).

Do not commit secrets, API keys, SMTP passwords, or Cloudflare access tokens.

## Important

Before production deployment:

1. Test every page.
2. Test mobile navigation.
3. Test `/robots.txt` and `/sitemap.xml`.
4. Configure the Cloudflare Email Service `EMAIL` binding if using the supplied form function.
5. Test the contact form.
6. Only then connect the production domain/DNS.

## Company

**NGP INTEGRATED SERVICES LIMITED**  
RC: 7738832  
Email: ngpintegratedserviceslimited@gmail.com  
Website: https://ngpintegratedservices.com/
