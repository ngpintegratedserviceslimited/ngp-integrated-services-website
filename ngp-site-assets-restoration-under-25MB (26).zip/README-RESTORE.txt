NGP WEBSITE ASSET RESTORATION PACKAGE

This package contains 29 recovered original files from the uploaded img.zip.
Files are placed in the URL directory structure expected by the current website:
- media/assets/img/
- media/signageassets/img/

IMPORTANT:
- These files have NOT been uploaded to GitHub or deployed to Cloudflare.
- Upload the contents of this archive (the media/ folder) into the root of the GitHub repository.
- Do not rename files or flatten the folder structure.
- The website references additional assets that were not found by exact filename in the supplied archive. They are listed in missing-assets.txt.
- No substitute images have been invented.
